import java.util.ArrayList;
import java.util.List;

public class StringFormatter
{
	public static int totalLetters( List<String> wordList )
	{
		int sum = 0;
		for ( String word : wordList ){
			sum += word.length();
		}
		return sum;
	}
	
	public static int basicGapWidth( List<String> wordList, int formattedLen )
	{
		return (formattedLen - totalLetters(wordList))/(wordList.size()-1);
	}
	
	public static int leftoverSpaces( List<String> wordList, int formattedLen)
	{

		return formattedLen - totalLetters(wordList) - (basicGapWidth( wordList, formattedLen)*(wordList.size()-1));
	}
	
	public static String format( List<String> wordList, int formattedLen )
	{
		String form = "";

		for (int i = 0; i < wordList.size(); i++){
			for (int j = 0; j < basicGapWidth(wordList, formattedLen); j++){
				wordList.set(i, wordList.get(i)+" ");
			}

		}
		int left = leftoverSpaces(wordList, formattedLen);
		for (int k = 0; k < wordList.size(); k++){
			if (left > 0) {
				wordList.set(k, wordList.get(k) + " ");
			}
			left--;
		}
		for (int l = 0; l < wordList.size(); l++){
			form += wordList.get(l);
		}
		return form;
	}
}