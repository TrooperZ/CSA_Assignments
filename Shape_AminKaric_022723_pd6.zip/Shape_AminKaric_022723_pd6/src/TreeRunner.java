public class TreeRunner {
    public static void main(String[] args) {
        Sequioa t = new Sequioa(2.5);
        System.out.println(t);
    }
}
