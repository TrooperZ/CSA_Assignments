public abstract class Tree {
    int ageDiameterRatio=30;
    void calculateAge(){};
}
