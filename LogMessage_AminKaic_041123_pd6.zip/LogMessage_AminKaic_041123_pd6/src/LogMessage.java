public class LogMessage
{
	private String machineId;
	private String description;
	
    public LogMessage( String message ) 
    {
    	String[] stuff = message.split(":");
        machineId = stuff[0];
        description = stuff[1];
    }
    
    public void setMessage( String message )
    {
        String[] stuff = message.split(":");
        machineId = stuff[0];
        description = stuff[1];
    }
    
    public boolean containsWord( String keyword )
    {
        String[] arr = description.split(" ");
        for (String a : arr){
            if (a.equals(keyword)){
                return true;
            }
        }
        return false;

    }
    
    public String getMachineId()
    {
    	return machineId;
    }
    
    public String getDescription()
    {
    	return description;
    }
    
    public String toString()
    {
    	return "" + machineId + " " + description;
    }    
}