//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import static java.lang.System.*;

public class MazeRunner
{
	public static void main( String args[] ) throws IOException
	{
		File myObj = new File("C:\\Users\\troop\\Downloads\\Maze_AminKaric_040423_pd6\\src\\maze.dat");
		Scanner myReader = new Scanner(myObj);
		while (myReader.hasNextLine()) {
			String len = myReader.nextLine();
			String data = myReader.nextLine();
			Maze m = new Maze(Integer.parseInt(len.replaceAll("\\s", "")), data);
			System.out.println(m);
			System.out.println("Maze path: " + m.hasExitPath(0, 0));
		}
		myReader.close();
	}

}
