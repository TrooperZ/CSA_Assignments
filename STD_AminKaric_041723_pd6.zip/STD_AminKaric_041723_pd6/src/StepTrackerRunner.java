public class StepTrackerRunner
{
	public static void main(String[] args) 
	{
		StepTracker fun = new StepTracker(10000);
		System.out.println( fun.activeDays() );
		System.out.println( fun.averageSteps() );
		fun.addDailySteps( 9000 );
		fun.addDailySteps( 5000 );
		System.out.println( fun.activeDays() );
		System.out.println( fun.averageSteps() );
		fun.addDailySteps( 13000 );
		System.out.println( fun.activeDays() );
		System.out.println( fun.averageSteps() );
		fun.addDailySteps( 23000 );
		fun.addDailySteps( 1111 );		
		System.out.println( fun.activeDays() );
		System.out.println( fun.averageSteps() );		
	}
}


/*
output

0
0.0
0
7000.0
1
9000.0
2
10222.2

*/
