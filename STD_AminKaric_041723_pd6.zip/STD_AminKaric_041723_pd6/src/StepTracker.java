
public class StepTracker
{
    private int steps, aDays, minSteps, days;
    public StepTracker(int m) {
        minSteps=m;
        steps=aDays=days=0;
    }
    public int activeDays() {
        return aDays;
    }
    public double averageSteps() {
        return steps==0?0.0:(double)steps/days; //could just use an if
    } //felt like living on
    public void addDailySteps(int st) { //the wild side
        steps+=st;
        days++;
        if(st>=minSteps) {
            aDays++;
        }
    }
}