import java.util.*;

public class Delimiters
{
	private String openDel;
	private String closeDel;

	public Delimiters(String open, String close)
	{
		openDel = open;
		closeDel = close;
	}

	public ArrayList<String> getDelimitersList(String[] tokens)
	{
		ArrayList<String> fun;
		fun = new ArrayList<String>();
		for( String s : tokens )
		{
			if( s.equals( openDel ) ||
					s.equals( closeDel) )
				fun.add( s );
		}
		return fun;
	}

	public boolean isBalanced(ArrayList<String> delimiters)
	{
		int closeCount = 0;
		int openCount = 0;
		for( String s : delimiters )
		{
			if( s.equals( openDel ) )
			{
				openCount++;
			}
			else if( s.equals( closeDel ) )
			{
				closeCount++;
			}
			if( closeCount > openCount )
			{
				return false;
			}
		}
		return closeCount == openCount;
	}

}
