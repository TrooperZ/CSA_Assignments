public class AtCounterRunner {
	public static void main(String[] args) {
		String[][] arr = {
				{"@", "-", "@", "-", "-", "@", "-", "@", "@", "@"},
				{"@", "@", "@", "-", "@", "@", "-", "@", "-", "@"},
				{"-", "-", "-", "-", "-", "-", "-", "@", "@", "@"},
				{"-", "@", "@", "@", "@", "@", "-", "@", "-", "@"},
				{"-", "@", "-", "@", "-", "@", "-", "@", "-", "@"},
				{"@", "@", "@", "@", "@", "@", "-", "@", "@", "@"},
				{"-", "@", "-", "@", "-", "@", "-", "-", "-", "@"},
				{"-", "@", "@", "@", "-", "@", "-", "-", "-", "-"},
				{"-", "@", "-", "@", "-", "@", "-", "@", "@", "@"},
				{"-", "@", "@", "@", "@", "@", "-", "@", "@", "@"}
		};
		AtCounter counter = new AtCounter(arr);
		System.out.println(counter);

		int[][] locations = { { 0, 0 }, { 2, 5 }, { 5, 0 }, { 9, 9 }, { 3, 9 } };
		for (int[] loc : locations) {
			int r = loc[0];
			int c = loc[1];
			int count = counter.countAts(r, c);
			System.out.printf("%d %d has %d @s connected.%n", r, c, count);
		}

		AtCounter counter2 = new AtCounter(20, 20);
		System.out.println(counter2);
		System.out.println("0 0 has " + counter2.countAts(0, 0) + " @s connected");
		System.out.println("2 5 has " + counter2.countAts(2, 5) + " @s connected");
		System.out.println("5 0 has " + counter2.countAts(5, 0) + " @s connected");
		System.out.println("9 9 has " + counter2.countAts(9, 9) + " @s connected");
		System.out.println("3 9 has " + counter2.countAts(3, 9) + " @s connected");
	}
}
