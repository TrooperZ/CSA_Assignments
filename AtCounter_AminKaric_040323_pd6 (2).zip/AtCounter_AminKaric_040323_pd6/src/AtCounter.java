import java.util.Arrays;

public class AtCounter {
	private String[][] atMat;

	public AtCounter(int numRows, int numCols) {
		atMat = new String[numRows][numCols];

		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				double value = Math.random();

				if (value < 0.5) {
					atMat[i][j] = "@";

				}
				else {
					atMat[i][j] = "-";
				}
			}
		}
	}

	public AtCounter(String[][] atMat) {
		this.atMat = atMat;
	}

	public int countAts(int r, int c) {
		if (r < 0 || r >= atMat.length || c < 0 || c >= atMat[0].length || atMat[r][c].equals("-")) {
			return 0;
		}
		int count = 1;
		atMat[r][c] = "-";
		count += countAts(r - 1, c);
		count += countAts(r + 1, c);
		count += countAts(r, c - 1);
		count += countAts(r, c + 1);
		return count;
	}


	public String toString() {
		String s = "";
		for (String[] row : atMat) {
			for (String thing : row){
				s += thing + " ";
			}
			s += "\n";
		}
		return s;
	}
}
