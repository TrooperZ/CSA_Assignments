import java.util.Arrays;
import java.util.ArrayList;
import java.util.Random;
public class RandomStringChooser
{

    private String[] choices;
    public RandomStringChooser(String[] wordArray){
        this.choices = wordArray;
    }

    public String getNext(){
        if (choices.length == 0) {
            return "NONE";
        }
        Random rng = new Random();
        int num = rng.nextInt(0, choices.length);
        String word = choices[num];
        String[] newArray = new String[choices.length-1];
        int i = 0;
        boolean removed = false;
        for (int x = 0; x < choices.length; x++){
            if (choices[x].equals(word) && !removed){
                removed = true;

            }
            else {
                newArray[i] = choices[x];
                i++;

            }


        }
        choices = newArray;
        return word;

    }

     
    public String toString()
    {
    	return "" + Arrays.toString(choices);
    }    
}