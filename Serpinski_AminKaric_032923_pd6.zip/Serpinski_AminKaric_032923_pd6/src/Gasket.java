//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.Canvas;

public class Gasket extends Canvas implements Runnable
{
	private static final int WIDTH = 800;
	private static final int HEIGHT = 600;

	public Gasket()
	{
		setBackground(Color.WHITE);
	}

	public void paint( Graphics window )
	{
		window.setColor(Color.BLUE);
		window.setFont(new Font("ARIAL",Font.BOLD,24));
		window.drawString("Sierpinski's Gasket", 25, 50);

		gasket(window, (WIDTH-10)/2, 20, WIDTH-40, HEIGHT-20, 40, HEIGHT-20);
	}

	public void gasket(Graphics window, int x1, int y1, int x2, int y2, int x3, int y3) {
		if (Math.abs(x2 - x1) < 5 || Math.abs(y3 - y1) < 5) { // Base case, stop recursion when the triangle is too small
			return;
		}

		int xa = (x1 + x2) / 2;
		int ya = (y1 + y2) / 2;
		int xb = (x2 + x3) / 2;
		int yb = (y2 + y3) / 2;
		int xc = (x1 + x3) / 2;
		int yc = (y1 + y3) / 2;

		// Generate a random color for the triangle
		Color triangleColor = new Color((int)(Math.random() * 256), (int)(Math.random() * 256), (int)(Math.random() * 256));

		// Draw the triangle with the random color
		window.setColor(triangleColor);
		window.drawLine(x1, y1, x2, y2);
		window.drawLine(x2, y2, x3, y3);
		window.drawLine(x3, y3, x1, y1);

		// Generate a random color for the smaller triangle
		Color smallerTriangleColor = new Color((int)(Math.random() * 256), (int)(Math.random() * 256), (int)(Math.random() * 256));

		// Draw the smaller triangle with the white color
		window.setColor(smallerTriangleColor);
		window.drawLine(xa, ya, xb, yb);
		window.drawLine(xb, yb, xc, yc);
		window.drawLine(xc, yc, xa, ya);

		// Recursively call gasket() for the three smaller triangles
		gasket(window, x1, y1, xa, ya, xc, yc);
		gasket(window, xa, ya, x2, y2, xb, yb);
		gasket(window, xc, yc, xb, yb, x3, y3);
	}



	public void run()
	{
		try{
		  	Thread.currentThread().sleep(3);
		}
		catch(Exception e)
		{
		}
	}
}